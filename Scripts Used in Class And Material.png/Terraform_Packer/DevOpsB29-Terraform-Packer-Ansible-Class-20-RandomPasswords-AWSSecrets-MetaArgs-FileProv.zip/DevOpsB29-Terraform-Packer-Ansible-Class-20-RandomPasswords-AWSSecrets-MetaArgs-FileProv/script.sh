#!/bin/bash
apt update
apt install -y nginx net-tools jq unzip
