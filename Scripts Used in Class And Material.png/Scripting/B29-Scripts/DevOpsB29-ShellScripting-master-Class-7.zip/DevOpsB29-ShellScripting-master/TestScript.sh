#!/bin/bash
A=10
B=20
echo "The Value Of A is $A"
echo "The Value of B is $B"