foreach ($x in 1..100) {
    Write-Output $x
}