#!/bin/bash
#set -x -e
if [ $# -gt 0 ]; then
    USERS=$@
    for USER in ${USERS[@]}; do
        #if [[ "${USER}" =~ ^[a-zA-Z] ]]; then
        if [[ "${USER}" =~ ^[a-zA-Z]+$ ]]; then
            EXISTING_USER=$(cat /etc/passwd | grep -i -w $USER | cut -d ":" -f1)
            if [ "${EXISTING_USER}" = "${USER}" ]; then
                echo "USER WITH USERNAME $USER ALREADY EXISTS. TRY A DIFFERENT NAME"
            else
                echo "Lets Create User $USER"
                sudo useradd -m $USER --shell /bin/bash
                SPEC='!@#$%^&*()_'
                SPEC_CHAR=$(echo $SPEC | fold -w1 | shuf | head -1)
                PASSWD=India@${RANDOM}${SPEC_CHAR}
                echo "$USER:$PASSWD" | sudo chpasswd
                passwd -e $USER
                echo $PASSWD
            fi
        else
            echo "The Username Must Contain Only Alphabets"
        fi
    done
else
    echo "Please Enter Valid Input"
fi

#user_automation.sh tesuser1 tesuser2 tesuser3 tesuser4 tesuser5
